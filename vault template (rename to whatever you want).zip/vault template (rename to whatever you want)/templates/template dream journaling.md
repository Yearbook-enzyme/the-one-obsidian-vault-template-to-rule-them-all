
# Dream Journaling

## Metadata:
- **Date**: {{date}}
- **Mood upon waking**: 
- tags: #dj
## Dream Description:
- 

## Key Elements and Patterns:
### Characters:
- `#character/NameHere`

### Locations:
- `#location/LocationHere`

### Objects:
- `#object/ObjectName`

### Themes/Emotions:
- `#theme/ThemeHere`
- `#emotion/EmotionHere`

## Potential Triggers:
- `#trigger/TriggerHere`

## Reality Checks:
- `#realitycheck/CheckType`

## Lucidity:
- `#lucid`
- `#clarity/LevelHere`

## Reflection:
- 

## Actions for Next Time:
- 

---

