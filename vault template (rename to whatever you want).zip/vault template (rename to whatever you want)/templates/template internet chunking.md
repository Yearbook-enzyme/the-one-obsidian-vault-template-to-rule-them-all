Internet Chunking - [#internet-chunking/Topic Name]

- Objective: 
  - Why are you collecting information about this topic? 
  - What do you hope to achieve?

- Resources:
  - Must-Reads: 
    - [ ] Link/Resource 1
    - [ ] Link/Resource 2
    - [ ] ...
  - Further Exploration: 
    - [ ] Link/Resource 1
    - [ ] Link/Resource 2
    - [ ] ...

- Key Takeaways: 
  - Point 1
  - Point 2
  - ...

- Next Actions: 
  - [ ] Task/Action 1
  - [ ] Task/Action 2
  - [ ] ...

- Related Links: these are to be backlinked
  - [Link to related random thoughts/concept 1]
  - [Link to related random thoughts/concept 2]
  - ...