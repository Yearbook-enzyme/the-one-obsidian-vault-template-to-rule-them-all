
# Finances

## Startup Costs
- **Item 1**: Amount
- **Item 2**: Amount

## Monthly Operating Costs
- **Rent**: Amount
- **Utilities**: Amount
- **Salaries**: Amount

## Revenue Streams
- **Product/Service 1**: Amount
- **Product/Service 2**: Amount

## Financial Projections
- **Month 1**: Amount
- **Month 2**: Amount

## Investment & Funding
- **Investor 1**: Amount
- **Investor 2**: Amount
