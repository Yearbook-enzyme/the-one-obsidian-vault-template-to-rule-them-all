
# Team & Collaboration

## Team Members
- **Name 1**:
  - **Role**:
  - **Responsibilities**:
  - **Contact**:

## Collaboration Tools
- **Communication**: Tool name (e.g., Slack, Teams)
- **Project Management**: Tool name (e.g., Trello, Asana)
- **File Sharing**: Tool name (e.g., Google Drive, Dropbox)

## Team Meetings & Check-ins
- **Daily Standup**: Time
- **Weekly Review**: Time & Date
