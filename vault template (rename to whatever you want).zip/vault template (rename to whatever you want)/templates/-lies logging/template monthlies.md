
# Monthly Review

## Metadata:
- Date: {{date}}
- Mood: 
- tags: #monthlies 
## Goals Review:
- Goal 1: 
  - Progress: 
  - Reflection: 
- Goal 2:
  - Progress: 
  - Reflection: 

## Activities Overview:
- Major Activity 1:
  - Details: 
  - Outcome: 
- Major Activity 2:
  - Details: 
  - Outcome: 

## Reflection:
- Lesson 1:
- Lesson 2:

## Plans for Next Month:
- Objective 1:
- Objective 2:

---

