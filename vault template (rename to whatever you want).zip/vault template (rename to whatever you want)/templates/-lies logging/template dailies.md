
# Daily Log

## Metadata:
- Date: {{date}}
- Mood: 
- Main Activity: 
- tags: #dailies 
## Lingering feelings, Observations, and Thoughts:
### What made you happy today?
- 

### What's one thing you learned today?
- 

### Did I practice any aspect of maker culture today? change this question out for something else specific to you
- 

## Reflection:
### Progress towards business idea:
- 

### Activities or routines related to sleep, diet, exercise:
- 

## Today's Notes:
### Business Progress:
- 

### Maker Activity, change "maker" for your thing in the previous question:
- 

### Lucid Dreaming Notes:
- 

---

