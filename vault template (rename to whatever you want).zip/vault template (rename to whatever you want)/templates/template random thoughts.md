- Date: {{date}}
  Time: {{time}}

- Initial Thought: 
  - Capture the thought as it first came to you.

- Trigger: 
  - What prompted this thought? Activity, reading, conversation, etc.

- Further Exploration: 
  - Expand on the thought, its implications, or related ideas.

- Related Thoughts/Links: these are to be backlinked
  - [Link to related note/thought 1]
  - [Link to related note/thought 2]
  - ...

- Actionable Steps: 
  - [ ] Potential action or follow-up based on this thought.
  - [ ] Another action or exploration point.