# Title of the Game

## General Information
- **Release Date**: 
- **Developer(s)**: 
- **Publisher(s)**: 
- **Genre**: 
- **Platform(s)**: 
- **Rating (Your Personal Rating)**: 
- **Game Tag** (unhide to use tag): `#game/game-name`

## Synopsis
Brief summary or synopsis of the game.

## Personal Review
Your thoughts, feelings, and review of the game.

## Key Takeaways
Any lessons, quotes, or significant moments from the game.

---
Related Backlinked Notes: [Link to related notes]
