# Title of the episode

## General Information
- **Release Date**: 
- **Creator(s)**: 
- **Genre**: 
- **Duration**: 
- **Rating (Your Personal Rating)**: 
- **Series Tag** (unhide to use tag): `#series/series-name`

## Synopsis
Brief summary or synopsis of the media.

## Personal Review
Your thoughts, feelings, and review of the media.

## Key Takeaways
Any lessons, quotes, or significant moments from the media.

---
Related backlinked Notes: [Link to related notes]
