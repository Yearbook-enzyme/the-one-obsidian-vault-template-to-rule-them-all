created: 2023-09-08 19:00
tag: #todo
# 💠 todo list
## 🔴 URGENT
*Do it now*
- [ ] task 1
- [ ] task 2
- [ ] task 3
### 🟠 IMPORTANT 
*Do it after tasks above*
- [ ] task 4
- [ ] task 5
- [ ] task 6
#### 🟡 NOT URGENT / IMPORTANT
*Decide when to do it* 
- [ ] task 7
- [ ] task 8
- [ ] task 9