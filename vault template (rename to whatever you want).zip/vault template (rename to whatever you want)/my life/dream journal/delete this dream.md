
# Dream Journaling

## Metadata:
- **Date**: 2023-09-14
- **Mood upon waking**: mood here
- tags: #dj
## Dream Description:
- rough general dream details

## Key Elements and Patterns:
be sure to unhide the tags so they function
### Characters:
- `#dj/character/NameHere`

### Locations:
- `#dj/location/LocationHere`

### Objects:
- `#dj/object/ObjectName`

### Themes/Emotions:
- `#dj/theme/ThemeHere`
- `#dj/emotion/EmotionHere`

## Potential Triggers:
- `#dj/trigger/TriggerHere`

## Reality Checks:
- `#dj/realitycheck/CheckType`

## Lucidity:
- `#dj/lucid`
- `#dj/clarity/LevelHere`

## Reflection:
- try to make meaningful connetions in your mind to stuff in the dream

## Actions for Next Time:
- whatever actions you feel like or nothing at all

---

