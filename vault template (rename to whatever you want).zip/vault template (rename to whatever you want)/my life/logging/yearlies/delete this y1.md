# Yearly Review and Goals

## Metadata:
- Date: 2023-09-12
- tags: #yearlies 
## Year in Review:
### Highlights:
- 
- 
- 

### Challenges Faced:
- 
- 
- 

### Lessons Learned:
- 
- 
- 

## Reflection on Goals:
### Achieved Goals:
- 
- 
- 

### Unfinished Goals:
- 
- 
- 

### Unexpected Achievements:
- 
- 
- 

## Skill & Personal Development:
### Maker Projects:
- 
- 
- 

### Community Engagement:
- 
- 
- 

### Personal Growth:
- 
- 
- 

## Plans for the Upcoming Year:
### Personal Goals:
- 
- 
- 

### Skill Development Goals:
- 
- 
- 

### Community and Social Goals:
- 
- 
- 

## Closing Thoughts:
### Anticipations:
- 
- 
- 

### Personal Message:
- 

---

