# game name

## General Information
- **Release Date**: release date here
- **Developer(s)**: developer here
- **Publisher(s)**: publisher here
- **Genre**: genre here
- **Platform(s)**: platform here
- **Rating (Your Personal Rating)**: rating here
- **Game Tag**: `#games/game-name`

## Synopsis
this is what happens

## Personal Review
wowee coooool

## Key Takeaways
cool things you saw

---
Related Backlinked Notes: [Link to related notes]