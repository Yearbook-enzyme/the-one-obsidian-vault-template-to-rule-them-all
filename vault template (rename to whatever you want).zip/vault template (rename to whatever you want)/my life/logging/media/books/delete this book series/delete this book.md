# Title of the Book

## General Information
- **Publication Date**: publication date here
- **Author**: author here
- **Genre**: genre here
- **number of Pages**: number of pages here
- **Rating (Your Personal Rating)**: rating here
- **Book Tag** (unhide to use tag): `#books/book-name`

## Synopsis
wowee 1

## Personal Review
wowee 2

## Key Takeaways
wowee 3

---
Related Backlinked Notes: [Link to related notes]
