# episode name

## General Information
- **Release Date**: release date here
- **Creator(s)**: creator here
- **Genre**: genre here
- **Duration**: duration here
- **Rating (Your Personal Rating)**: rating here
- **Series Tag** (unhide to use tag): `#series/series-name`

## Synopsis
what happens

## Personal Review
your thoughts

## Key Takeaways
neat stuff

---
Related Backlinked Notes: [Link to related notes]
