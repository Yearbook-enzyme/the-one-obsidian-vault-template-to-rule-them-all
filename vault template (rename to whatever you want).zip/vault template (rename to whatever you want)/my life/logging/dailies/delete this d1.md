
# Daily Log

## Metadata:
- Date: 2023-09-14
- Mood: mood here
- Main Activity: main activity here
- tags: #dailies 
## Lingering feelings, Observations, and Thoughts:
### What made you happy today?
- things and stuff

### What's one thing you learned today?
- more things and stuff

### Did I practice any aspect of maker culture today?
- put what you need to here

## Reflection:
### Progress towards business idea:
- your progress here

### Activities or routines related to sleep, diet, exercise:
- some things you are doing

## Today's Notes:
### Business Idea Progress:
- things and stuff

### Maker Activity:
- more things and stuff

### Lucid Dreaming Notes:
- other more different stuff

---

