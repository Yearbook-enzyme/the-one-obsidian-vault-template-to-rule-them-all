- Date: 2023-09-13
  Time: 11:35

- Initial Thought: 
  - quickly note some words

- Trigger: 
  - what triggered the thought

- Further Exploration: 
  - some more words

- Related Thoughts/Links: these are to be backlinked
  - [Link to related note/thought 1]
  - [Link to related note/thought 2]
  - ...

- Actionable Steps: 
  - [ ] find out how to make this into a business opportunity
  - [ ] develop a plan for said opportunity